import sys
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from Ui_mm import *
from lxml import etree
from bs4 import BeautifulSoup
import time
import webbrowser 
import urllib.request
import re
import os
import datetime,socket
import random
import requests



global keyword,page,dict_data,line_url
class MyMainWindow(QMainWindow, Ui_MainWindow):
    def __init__(self, parent=None):
        global keyword,page,dict_data,line_url
        super(MyMainWindow, self).__init__(parent)
        self.setupUi(self)
        QApplication.setStyle('Fusion')
        self.urllist = []
        self.titlelist = []
        self.lineEdit.setReadOnly(True)

        self.yulan.setText("<a href='#'>预 览</a>")
        self.start_Button.clicked.connect(self.start_Worker)
        self.yulan.linkActivated.connect(self.pvw_html)

        self.pushButton.clicked.connect(self.start_Download_Worker)
        self.pushButton_4.clicked.connect(self.start_Download_Worker)
        self.pushButton_2.clicked.connect(self.refresh)
        self.listWidget_2.itemClicked.connect(self.show_line)
        self.listWidget_3.itemClicked.connect(self.show_line)
        self.listWidget_4.itemClicked.connect(self.show_line)
        self.listWidget_5.itemClicked.connect(self.show_line)


    def pvw_html(self):
        if self.lineEdit_2.text():
            self.url =  "https://pixabay.com/zh/photos/?min_height=&image_type=photo&cat=&q="+ str(self.lineEdit_2.text())+ "&min_width=&order=&pagi=0" 
            webbrowser.open(self.url)
        else:
            QMessageBox.critical(self, '警告','请输入主题！')

    def start_Worker(self):
        global keyword,page
        if self.lineEdit_2.text() and self.pagr_num.value():  # 判断主题框和页码框是否有值
            self.listWidget_6.clear()  # 清屏
            keyword = self.lineEdit_2.text()
            page = self.pagr_num.value()
            self.worker = Worker()  # 实例化线程类
            self.worker.update_date.connect(self.dispaly)
            self.listWidget_6.addItem('开始下载！')
            self.worker.start()
        else:
            QMessageBox.critical(self, '警告','请选择主题！')

    def start_Download_Worker(self):
        global keyword,page,dict_data,line_url,isdown,sender,current_text
        sender1 = self.sender()
        sender = True
        current_text = self.comboBox.currentText()
        if current_text == 'x':
            print('dui a ')
        if self.lineEdit.text():
            if sender1 == self.pushButton_4:
                self.pushButton_4.setEnabled(False)
                sender = self.pushButton_4.isEnabled()
                print(sender)
            else:
                pass
            self.pushButton_4.setEnabled(True)
            line_url = self.lineEdit.text()
            self.download = Download_Worker()
            self.download.update_date2.connect(self.dispaly_label)
            self.download.start()
        else:
            QMessageBox.critical(self, '错误','请选择主题！！')

    def dispaly(self,data):
        self.listWidget_6.addItem(data)  
    
    def dispaly_label(self,data):
        self.statusbar.showMessage(data)

    def refresh(self):
        global dict_data,line_url
        x = 1
        for a in range(2, 3):

            url = 'http://www.99mm.me/meitui/mm_1_'+str(a)+'.html'
            url2 = 'http://www.99mm.me/xinggan/mm_2_'+ str(a) + '.html'
            url3 = 'http://www.99mm.me/qingchun/mm_3_'+ str(a) + '.html'
            url4 = 'http://www.99mm.me/hot/mm_4_'+ str(a) + '.html'
            response = requests.get(url)
            response2 = requests.get(url2)
            response3 = requests.get(url3)
            response4 = requests.get(url4)
            response.encoding = 'utf-8'
            response2.encoding = 'utf-8'
            response3.encoding = 'utf-8'
            response4.encoding = 'utf-8'

            all_urls = BeautifulSoup(response.text, 'lxml').find('ul', id='piclist').find_all('dd')
            all_urls2 = BeautifulSoup(response2.text, 'lxml').find('ul', id='piclist').find_all('dd')
            all_urls3 = BeautifulSoup(response3.text, 'lxml').find('ul', id='piclist').find_all('dd')
            all_urls4 = BeautifulSoup(response4.text, 'lxml').find('ul', id='piclist').find_all('dd')
            
            for i in all_urls:
                a = i.find_all('a')
                for url in a:
                    title = url.get_text()
                    href = url['href']
                    urls = 'http://www.99mm.me/' + href
                    self.listWidget_5.addItem(str(title))
                    self.urllist.append(urls)
                    self.titlelist.append(title)
            self.listWidget_5.addItem('-----------------------'+str(x)+'------------------------')
            for i in all_urls2:
                a = i.find_all('a')
                for url in a:
                    title = url.get_text()
                    href = url['href']
                    urls = 'http://www.99mm.me/' + href
                    self.listWidget_3.addItem(str(title))
                    self.urllist.append(urls)
                    self.titlelist.append(title)
            self.listWidget_3.addItem('-----------------------'+str(x)+'------------------------') 
          
            for i in all_urls3:
                a = i.find_all('a')
                for url in a:
                    title = url.get_text()
                    href = url['href']
                    urls = 'http://www.99mm.me/' + href
                    self.listWidget_2.addItem(str(title))
                    self.urllist.append(urls)
                    self.titlelist.append(title)  
            self.listWidget_2.addItem('-----------------------'+str(x)+'------------------------')

            for i in all_urls4:
                a = i.find_all('a')
                for url in a:
                    title = url.get_text()
                    href = url['href']
                    urls = 'http://www.99mm.me/' + href
                    self.listWidget_4.addItem(str(title))
                    self.urllist.append(urls)
                    self.titlelist.append(title)
            self.listWidget_4.addItem('-----------------------'+str(x)+'------------------------') 
            QApplication.processEvents()
            time.sleep(0.1) 
            x += 1
        zip1 = zip(self.titlelist,self.urllist)
        dict_data = dict(zip1)
           
    def show_line(self, item):
        if len(item.text())<30:
            self.lineEdit.setText(item.text())
        else:
            pass


class Worker(QThread):
#这是一个线程类，用来完成下载图片的功能。

    update_date = pyqtSignal(str)

    def __init__(self, parent=None):
        super(Worker, self).__init__(parent)
        global keyword,page    #定义两个全局变量关键字和页码
        self.filepath(keyword)  

    def filepath(self,keyword):  # 建立一个文件夹，以keyword命名文件
        if not os.path.exists(keyword):
            try:
                os.makedirs(os.path.abspath('.') + "\\" + keyword)
                self.absfilepath = os.path.abspath(str(keyword))    # 将文件夹的绝对路径赋给变量
            except:
                self.absfilepath = os.path.abspath(str(keyword))
        else:
            self.absfilepath = os.path.abspath(str(keyword))

    def run(self):
        for i in range(1, page+1):  # 一页一页下载
            url =  "https://pixabay.com/zh/photos/?min_height=&image_type=photo&cat=&q="+ str(keyword)+ "&min_width=&order=&pagi=" +str(i)
            headers = {
                'Host':'pixabay.com',
                'User-Agent':'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.146 Safari/537.36',
            }
            html1 =requests.get(url,headers)
            html1 = html1.text
            #正则表达式提取出图片网址
            pat1 = ' https://cdn.pixabay.com/photo/.*?\_480.jpg '
            result1 = re.compile(pat1).findall(str(html1))
            pat2 = 'https://cdn.pixabay.com/photo/.*?__480.jpg'
            imagelist = re.compile(pat2).findall(str(result1))

            self.update_date.emit('保存路径为：'+str(self.absfilepath))
            self.update_date.emit('开始下载第'+str(i)+'页,一共'+str(len(imagelist))+'张图片')
            x = 1
            for imageurl in imagelist:
                if len(imageurl) < 100:  # 过滤掉不正常的网址
                    imagename = os.path.join(self.absfilepath,str(i) + str(x) +'.jpg')
                    try:
                        start = datetime.datetime.now()
                        socket.setdefaulttimeout(10)  # 限制下载时间为10秒
                        urllib.request.urlretrieve(imageurl, filename=imagename)  # 下载图片
                        end = datetime.datetime.now()
                        usetime = (end - start).total_seconds()  # 通过记录下载前已下载后的时间来计算下载图片所用时间
                        self.update_date.emit('正在下载第'+str(i)+'页，第'+str(x)+'张;用时'+str(usetime)+'秒') 
                    except socket.timeout:
                        count = 1
                        while count <= 3:
                            try:
                                self.update_date.emit('你这破网速不行啊！重新下载第'+str(i)+'页，第'+str(x)+'张图片')
                                urllib.request.urlretrieve(imageurl, filename=imagename)
                                break
                            except socket.timeout:
                                count += 1
                            except urllib.error.URLError as e:
                                pass
                        self.update_date.emit('下载失败！算了！下一张！')  
                    x += 1
            self.update_date.emit('下载完成！')

class Download_Worker(QThread):

    update_date2 = pyqtSignal(str)

    def __init__(self, parent=None):
        super(Download_Worker, self).__init__(parent)
        self.titlelist = []
        self.urllist = []
        self.title = ''
        self.path = ''

    def request(self, url):
        headers = {'User-Agent': "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1"}
        response = requests.get(url, headers=headers)
        response.encoding = 'utf-8'
        return response

    def dirpath(self, path):
        self.path =path.strip()
        self.filename = os.path.join("D:\99mm", self.path)
        #print('正在创建', path)
        self.update_date2.emit('正在创建：' + str(self.path))
        if not os.path.exists(self.filename):
            os.makedirs(self.filename)
            os.chdir(self.filename)
            return True
        else:
            self.update_date2.emit('已存在‘'+ str(self.path) + '’目录')
            return False

    # 解析出每个图集的网址
    def all_url(self, url):

        html = self.request(url)
        all_urls = BeautifulSoup(html.text, 'lxml').find('ul', id='piclist').find_all('dd')

        for d in all_urls:
            a = d.find_all('a')
            for url in a:
                self.title = url.get_text()
                href = url['href']
                urls = 'http://www.99mm.me/' + href
                #print(urls)
                path = str(self.title)
                if not self.dirpath(path):
                    self.update_date2.emit('跳过目录：'+ str(self.title))
                self.detail_url(urls)
        
    def detail_url(self,urls):
        html = self.request(urls)
        page_num = BeautifulSoup(html.text,'lxml').find('div', class_='column').find('span').get_text().replace('.P','').strip()
        self.update_date2.emit(str(page_num) +'张')
        for num in range(1, int(page_num) + 1):
            short_url = urls + '?url='
            page_url = short_url + str(num)
            self.img(page_url, short_url, num)

    # 解析出单张图片网址
    def img(self, page_url,short_url, num):
        html = self.request(page_url)
        src = BeautifulSoup(html.text, 'lxml').find_all('script', type='text/javascript')[-2].get_text()[12:].split('%')
        img_url =  'http://img.99mm.net/{}/{}/'.format(src[4], src[5]) + str(num) + '-{}.jpg'.format(src[num + 7].replace("';", '').lower())
        refer_url = short_url + str(num-1)
        self.save_img(img_url, refer_url, num)
    
    # 保存每张图片
    def save_img(self, img_url, refer_url, num):
        name = str(num)
        try:
            self.update_date2.emit('正在下载<<'+str(self.path)+'>>第'+str(name)+'张')
            imgs = self.requestpic(img_url, Referer=refer_url).content
            f = open(name + '.jpg', 'ab')
            f.write(imgs)
            f.close()
        except FileNotFoundError as e:
            #self.update_date2.emit('图片找不到，跳过'+str(img_url))
            return False

    def requestpic(self, url, Referer): ##这个函数获取网页的response 然后返回
        user_agent_list = [ \
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/22.0.1207.1 Safari/537.1" \
            "Mozilla/5.0 (X11; CrOS i686 2268.111.0) AppleWebKit/536.11 (KHTML, like Gecko) Chrome/20.0.1132.57 Safari/536.11", \
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1092.0 Safari/536.6", \
            "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.6 (KHTML, like Gecko) Chrome/20.0.1090.0 Safari/536.6", \
            "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.1 (KHTML, like Gecko) Chrome/19.77.34.5 Safari/537.1", \
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.9 Safari/536.5", \
            "Mozilla/5.0 (Windows NT 6.0) AppleWebKit/536.5 (KHTML, like Gecko) Chrome/19.0.1084.36 Safari/536.5", \
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 5.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3", \
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_8_0) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1063.0 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1062.0 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.1 Safari/536.3", \
            "Mozilla/5.0 (Windows NT 6.2) AppleWebKit/536.3 (KHTML, like Gecko) Chrome/19.0.1061.0 Safari/536.3", \
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24", \
            "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/535.24 (KHTML, like Gecko) Chrome/19.0.1055.1 Safari/535.24"
            "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/49.0.2623.221 Safari/537.36 SE 2.X MetaSr 1.0"
        ]
        ua = random.choice(user_agent_list)
        headers = {'User-Agent': ua,"Referer":Referer} ##较之前版本获取图片关键参数在这里
        try:
            response = requests.get(url, headers=headers)
            response.encoding = 'utf-8'
            return response
        except:
            pass

    # 得到标题和对应网址的字典
    def make_dict(self,key1,value1):
        global dict_data
        result = zip(key1,value1)
        dict_data = dict(result)
        return dict_data

    def run(self):
        global current_text
        if sender == False:
            if not self.dirpath(line_url):
                self.update_date2.emit('跳过目录：'+ str(line_url))
            self.detail_url(dict_data[line_url])
            self.update_date2.emit('下载完成！保存路径：'+str(self.filename))
        elif current_text == '   写 真 美 女':
            for i in range(2, 3):
                url = 'http://www.99mm.me/meitui/mm_1_' + str(i) + '.html'
                self.all_url(url)      
        elif current_text == '   性 感 美 女':
            for i in range(2, 3):
                url = 'http://www.99mm.me/xinggan/mm_2_' + str(i) + '.html'
                self.all_url(url)   
        elif current_text == '   清 纯 美 女':
            for i in range(2, 3):
                url = 'http://www.99mm.me/qingchun/mm_3_' + str(i) + '.html'
                self.all_url(url)   
        elif current_text == '   人 气 美 女':
            for i in range(2, 3):
                url = 'http://www.99mm.me/hot/mm_4_' + str(i) + '.html'
                self.all_url(url)                   
if __name__=="__main__":
    
    app = QApplication(sys.argv)
    myWin = MyMainWindow()
    myWin.show()
    sys.exit(app.exec_())
